<?php
error_reporting(0);
ini_set('display_errors', false);
require_once __DIR__ . DIRECTORY_SEPARATOR . 'apiconfig.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'class'. DIRECTORY_SEPARATOR . 'xcp.class.php';
error_reporting(E_ERROR);
ini_set('display_errors', true);

$odds = $inner = array();
foreach($_GET as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values)?$values:md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}
foreach($_POST as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values)?$values:md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}
foreach(parse_url('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].(strpos($_SERVER['REQUEST_URI'], '?')?'&':'?').$_SERVER['QUERY_STRING'], PHP_URL_QUERY) as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values)?$values:md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}

$errors = array();
switch ($inner['mode']) {
    case "calc":
        if (!isset($inner['precision']) && empty($inner['precision']))
            $errors[] = array(301 => 'Decimal Precision Missing from the submission in POST/GET!');
        if (!isset($inner['seed']) && empty($inner['seed']))
            $errors[] = array(302 => 'XCP Seed Missing from the submission in POST/GET!');
        elseif (!is_numeric($inner['seed']) || ($inner['seed'] < 0 && $inner['seed'] > 255))
            $errors[] = array(303 => 'XCP Seed is either not a numeric or is greater than 255 or less than zeron in submission in POST/GET!');
        if (!isset($inner['limit']) && empty($inner['limit']))
            $errors[] = array(304 => 'XCP Length Limit is Missing from the submission in POST/GET!');
        elseif (!is_numeric($inner['limit']) || $inner['limit'] < 1)
            $errors[] = array(305 => 'XCP Length Limit is either not numeric or lesser than one in POST/GET!');
        if (!isset($inner['value']) && empty($inner['value']))
            $errors[] = array(306 => 'Value is Missing from the submission in POST/GET to get XCP Checksum From!');
        if (!isset($inner['format']) && empty($inner['format']))
            $errors[] = array(307 => 'Format of return is missing from the submission in POST/GET!');
        elseif (!in_array($inner['format'], array('raw', 'serial', 'json', 'xml')) && !empty($inner['format']))
            $errors[] = array(307 => 'Format of return is must only be: raw or serial or json or xml in POST/GET!');
        break;
}

if (count($errors) > 0) {
    if (function_exists("http_response_code"))
        http_response_code(500);
    switch ($inner['format']) {
        case 'raw':
            die("<?php\n\n return " . var_export($errors, true) . ";\n\n?>");
            break;
        default:
        case 'json':
            header('Content-type: application/json');
            die(json_encode($errors));
            break;
        case 'serial':
            header('Content-type: text/html');
            die(serialize($errors));
            break;
        case 'xml':
            header('Content-type: application/xml');
            $dom = new XmlDomConstruct('1.0', 'utf-8');
            $dom->fromMixed(array('errors'=>$errors));
            die($dom->saveXML());
            break;
    }
}

ini_set('precision', $inner['precision']);

$data = array();
set_time_limit(7600);
$crc = new xcp($inner['value'], $inner['seed'], $inner['limit']);
    
$data['seed'] = $crc->seed;
$data['limit'] = $crc->limit;
$data['precision'] = $inner['precision'];
$data['data']['sha1'] = sha1($inner['value']);
$data['data']['md5'] = md5($inner['value']);
$data['data']['bytes'] = strlen($inner['value']);
$data['xcp'] = $crc->crc;
    
if (function_exists("http_response_code"))
    http_response_code(201);

switch ($inner['format']) {
    case 'raw':
        die("<?php\n\n return " . var_export($data, true) . ";\n\n?>");
        break;
    default:
    case 'json':
        header('Content-type: application/json');
        die(json_encode($data));
        break;
    case 'serial':
        header('Content-type: text/html');
        die(serialize($data));
        break;
    case 'xml':
        header('Content-type: application/xml');
        $dom = new XmlDomConstruct('1.0', 'utf-8');
        $dom->fromMixed(array('root'=>$data));
        die($dom->saveXML());
        break;
}
?>

</pre>
