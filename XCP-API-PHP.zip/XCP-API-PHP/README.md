## Chronolabs Cooperative presents
# eXtensible Checksum Process (XCP) 
## Fractal Bitwise Checksum/HashInfo Code
### Author: Dr. Simon Antony Roberts (AU) <simon@snails.email>

#### Checksum 5000 - it a race that involves trains, utes, trucks, cars, bikes, planes, ufo's! ~ http://xcp.snails.email

### GitHub: https://github.com/Chronolabs-Cooperative/XCP---Fractal-Checksum

### Sourceforge: https://sourceforge.net/p/chronolabs-cooperative/XCP---Fractal-Checksum/

# Psuedomising Library Notes

If you are reproducing this checksum in other languages or as an executable or script remember you will need to be able with the function either calling without anything of these specified just with the PHP Defaults; or an executable switch for --seed + --length as well as --precision for decimal place precision in the checksum/hashinfo operating environmentals!